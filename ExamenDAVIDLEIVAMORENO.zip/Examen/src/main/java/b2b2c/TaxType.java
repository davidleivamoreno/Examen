package b2b2c;

public enum TaxType {
    General,Reduced,Superreduced
}
