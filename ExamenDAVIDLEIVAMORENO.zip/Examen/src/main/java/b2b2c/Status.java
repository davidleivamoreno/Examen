package b2b2c;

public enum Status  {
    PaymentComplete,Pending
}
